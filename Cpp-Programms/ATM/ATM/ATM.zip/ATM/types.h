typedef unsigned int uint32_t;
